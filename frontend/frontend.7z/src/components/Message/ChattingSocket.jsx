// 소켓 초기화 및 대화 내용을 표시하는 역할

import React from "react";

const ChattingSocket = () => {
  return <div></div>;
};

export default ChattingSocket;
