import styles from "@/styles/MyPage/WelfareList.module.css";

const WelfareList = () => {
  return (
    <>
      <div className={styles.title}>복지 포인트 내역</div>
      <div className={styles.table}>
        <div></div>
      </div>
    </>
  );
};
export default WelfareList;
